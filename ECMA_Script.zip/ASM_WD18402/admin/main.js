import { productService, orderService, userService, categoryService } from "../model/model.js";

document.addEventListener("DOMContentLoaded", () => {
  // Function to show products
  const showPro = () => {
    const tbody = document.getElementById("show-pro");
    if (tbody) {
      tbody.innerHTML = "";
      productService.fetchData("http://localhost:3000/product").then((data) => {
        data.forEach((item) => {
          tbody.innerHTML += `
            <tr>
              <td>${item.id}</td>
              <td>${item.name}</td>
              <td><img src="../site/images/${item.image}" width="120"></td>
              <td>${item.price}</td>
              <td>${item.sale}</td>
              <td>${item.category}</td>
              <td>${item.new}</td>
              <td>${item.star}</td>
              <td>${item.description}</td>
              <td>
                <button class="btn deletePro" data-id="${item.id}"><i class="fa-solid fa-trash"></i></button>
                <button class="btn openEditPage" data-id="${item.id}"><i class="fa-solid fa-pen-to-square"></i></button>
              </td>
            </tr>
          `;
        });
      });
    }
  };

  // Function to show categories
  const showCate = () => {
    const tbody = document.getElementById("show-category");
    if (tbody) {
      tbody.innerHTML = "";
      categoryService.fetchData("http://localhost:3000/categorie").then((data) => {
        data.forEach((category) => {
          tbody.innerHTML += `
            <tr>
              <td>${category.id}</td>
              <td>${category.name}</td>
              <td>${category.code}</td>
              <td>
                <button class="btn deleteCate" data-id="${category.id}"><i class="fa-solid fa-trash"></i></button>
                <button class="btn openEditCatePage" data-id="${category.id}"><i class="fa-solid fa-pen-to-square"></i></button>
              </td>
            </tr>
          `;
        });
      });
    }
  };
// show user

const showUser = () => {
  const tbody = document.getElementById("show-user");
  if (tbody) {
    tbody.innerHTML = "";
    userService.fetchData("http://localhost:3000/user").then((data) => {
      data.forEach((user) => {
        tbody.innerHTML += `
          <tr>
            <td>${user.id}</td>
            <td>${user.name}</td>
            <td>${user.email}</td>
            <td>${user.password}</td>
            <td>
              <button class="btn deleteUser" data-id="${user.id}"><i class="fa-solid fa-trash"></i></button>
              <button class="btn openEditUserPage" data-id="${user.id}"><i class="fa-solid fa-pen-to-square"></i></button>
            </td>
          </tr>
        `;
      });
    });
  }
};

//end show user
//show order

const showOrer = () => {
  const tbody = document.getElementById("show-order");
  if (tbody) {
    tbody.innerHTML = "";
    userService.fetchData("http://localhost:3000/order").then((data) => {
      data.forEach((order) => {
        tbody.innerHTML += `
          <tr>
            <td>${order.id}</td>
            <td>${order.name}</td>
            <td>${order.email}</td>
            <td>${order.password}</td>
            <td>
              <button class="btn deleteUser" data-id="${order.id}"><i class="fa-solid fa-trash"></i></button>
              <button class="btn openEditUserPage" data-id="${order.id}"><i class="fa-solid fa-pen-to-square"></i></button>
            </td>
          </tr>
        `;
      });
    });
  }
};

//end sohw order
  // Initialize functions to display products and categories
  showPro();
  showCate();
  showUser();
  showOrer();
  // Add product
  const addPro = () => {
    const name = document.getElementById("name").value;
    const fileInput = document.getElementById("image");
    const image = fileInput.files[0] ? fileInput.files[0].name : "No file chosen";
    const price = document.getElementById("price").value;
    const sale = document.getElementById("sale").value;
    const category = document.getElementById("category").value;
    const description = document.getElementById("description").value;
    const hotdeal = document.getElementById("new").checked;

    productService.getLastId().then((id) => {
      const newPro = {
        id: (Number(id) + 1).toString(),
        name: name,
        image: image,
        category: category,
        price: price,
        sale: sale,
        new: hotdeal ? 1 : 0,
        star: 5,
        description: description,
      };
      productService.addData(newPro).then(() => {
        showPro();
        modal.style.display = "none";
      });
    });
  };

  // Event listener for adding a product
  document.querySelector("#addPro").addEventListener("click", addPro);

  // Modal for adding product
  const modal = document.getElementById("myModal");
  document.getElementById("addButton").onclick = () => (modal.style.display = "block");
  document.getElementsByClassName("close")[0].onclick = () => (modal.style.display = "none");

  // Delete product
  const deletePro = (id) => {
    productService.deleteData(id).then(() => {
      showPro();
    });
  };

  // Event listener for deleting a product
  document.getElementById("show-pro").addEventListener("click", function (e) {
    if (e.target.closest(".deletePro")) {
      const id = e.target.closest(".deletePro").dataset.id;
      deletePro(id);
    }
  });

  // Edit product
  const editModal = document.getElementById("editModal");

  document.getElementById("show-pro").addEventListener("click", function (e) {
    if (e.target.closest(".openEditPage")) {
      const id = e.target.closest(".openEditPage").dataset.id;
      productService.getDataById(id).then((pro) => {
        editModal.style.display = "block";
        editModal.innerHTML = `
          <div class="modal-content">
            <span class="close">&times;</span>
            <label for="editName">Tên sản phẩm</label>
            <input value="${pro.name}" type="text" id="editName" />
            <label for="editImage">Hình ảnh</label>
            <img src="../site/images/${pro.image}" width="120" />
            <input type="file" id="editImage" />
            <input type="hidden" id="oldImage" value="${pro.image}" />
            <label for="editCategory">Danh mục</label>
            <select id="editCategory">
              <option value="gaubong" ${pro.category === "gaubong" ? "selected" : ""}>Gấu bông</option>
              <option value="hoa" ${pro.category === "hoa" ? "selected" : ""}>Hoa</option>
              <option value="trangsuc" ${pro.category === "trangsuc" ? "selected" : ""}>Trang sức</option>
            </select>
            <label for="editPrice">Giá</label>
            <input value="${pro.price}" type="text" id="editPrice" />
            <label for="editSale">Giá khuyến mãi</label>
            <input value="${pro.sale}" type="text" id="editSale" />
            <label for="editHotdeal">HotDeal</label>
            <input type="checkbox" id="editHotdeal" ${pro.new ? "checked" : ""} />
            <label for="editStar">Đánh giá</label>
            <input value="${pro.star}" type="text" id="editStar" />
            <label for="editDescription">Mô tả</label>
            <input value="${pro.description}" type="text" id="editDescription" />
            <button class="editPro" data-id="${id}">Sửa</button>
          </div>
        `;
      });
    }
  });

  // Event listener for editing a product
  editModal.addEventListener("click", function (e) {
    if (e.target.classList.contains("editPro")) {
      const id = e.target.dataset.id;
      const name = document.getElementById("editName").value;
      const oldImage = document.getElementById("oldImage").value;
      const fileInput = document.getElementById("editImage");
      const image = fileInput.files[0] ? fileInput.files[0].name : oldImage;
      const price = document.getElementById("editPrice").value;
      const sale = document.getElementById("editSale").value;
      const category = document.getElementById("editCategory").value;
      const description = document.getElementById("editDescription").value;
      const star = document.getElementById("editStar").value;
      const editHotdeal = document.getElementById("editHotdeal").checked;

      productService.updateData(id, {
        name: name,
        image: image,
        category: category,
        price: price,
        sale: sale,
        new: editHotdeal ? 1 : 0,
        star: star,
        description: description,
      }).then(() => {
        showPro();
        editModal.style.display = "none";
      });
    }
  });

  // Close edit modal
  editModal.addEventListener("click", function (e) {
    if (e.target.classList.contains("close")) {
      editModal.style.display = "none";
    }
  });

  // Search products by name
  const searchPro = (searchTerm) => {
    productService.fetchData("http://localhost:3000/product").then((data) => {
      const tbody = document.getElementById("show-pro");
      tbody.innerHTML = "";
      const filteredProducts = data.filter((item) => 
        item.name.toLowerCase().includes(searchTerm.toLowerCase())
      );
      filteredProducts.forEach((item) => {
        tbody.innerHTML += `
          <tr>
            <td>${item.id}</td>
            <td>${item.name}</td>
            <td><img src="../site/images/${item.image}" width="120"></td>
            <td>${item.price}</td>
            <td>${item.sale}</td>
            <td>${item.category}</td>
            <td>${item.new}</td>
            <td>${item.star}</td>
            <td>${item.description}</td>
            <td>
              <button class="btn deletePro" data-id="${item.id}"><i class="fa-solid fa-trash"></i></button>
              <button class="btn openEditPage" data-id="${item.id}"><i class="fa-solid fa-pen-to-square"></i></button>
            </td>
          </tr>
        `;
      });
    });
  };

  // Event listener for search button
  document.getElementById("searchButton").addEventListener("click", (e) => {
    e.preventDefault(); // Prevent default action of the button
    const searchTerm = document.getElementById("searchInput").value;
    searchPro(searchTerm);
  });
});
