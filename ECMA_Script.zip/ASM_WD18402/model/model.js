export class productService {
    static async fetchData(url) {
        try {
            const response = await axios.get(url);
            return response.data;
        } catch (error) {
            console.log(error);
            throw error;
        }
    }

    static async addData(data) {
        try {
            await axios.post('http://localhost:3000/product', data);
            console.log('Data has been added.');
        } catch (error) {
            console.log(error);
        }
    }
    
    static async deleteData(id) {
        try {
            await axios.delete(`http://localhost:3000/product/${id}`);
            console.log(`Data with id ${id} has been deleted.`);
        } catch (error) {
            console.log(error);
        }
    }

    static async updateData(id, data) {
        try {
            await axios.put(`http://localhost:3000/product/${id}`, data);
            console.log(`Data with id ${id} has been updated.`);
        } catch (error) {
            console.log(error);
        }
    }

    static async getDataById(id) {
        try {
            const response = await axios.get(`http://localhost:3000/product/${id}`);
            return response.data;
        } catch (error) {
            console.log(error);
            throw error;
        }
    }

    static async getLastId() {
        try {
            const response = await axios.get('http://localhost:3000/product');
            return response.data[response.data.length - 1].id;
        } catch (error) {
            console.log(error);
            throw error;
        }
    }
}


// category

export class categoryService {
    static async fetchData(url) {
        try {
            const response = await axios.get(url);
            return response.data;
        } catch (error) {
            console.log(error);
            throw error;
        }
    }

    static async addData(data) {
        try {
            await axios.post('http://localhost:3000/categories', data);
            console.log('Data has been added.');
        } catch (error) {
            console.log(error);
        }
    }
    
    static async deleteData(id) {
        try {
            await axios.delete(`http://localhost:3000/categories/${id}`);
            console.log(`Data with id ${id} has been deleted.`);
        } catch (error) {
            console.log(error);
        }
    }

    static async updateData(id, data) {
        try {
            await axios.put(`http://localhost:3000/categories/${id}`, data);
            console.log(`Data with id ${id} has been updated.`);
        } catch (error) {
            console.log(error);
        }
    }

    static async getDataById(id) {
        try {
            const response = await axios.get(`http://localhost:3000/categories/${id}`);
            return response.data;
        } catch (error) {
            console.log(error);
            throw error;
        }
    }

    static async getLastId() {
        try {
            const response = await axios.get('http://localhost:3000/categories');
            return response.data[response.data.length - 1].id;
        } catch (error) {
            console.log(error);
            throw error;
        }
    }
}

// user

export class userService {
    static async fetchData(url) {
        try {
            const response = await axios.get(url);
            return response.data;
        } catch (error) {
            console.log(error);
            throw error;
        }
    }

    static async addData(data) {
        try {
            await axios.post('http://localhost:3000/users', data);
            console.log('Data has been added.');
        } catch (error) {
            console.log(error);
        }
    }
    
    static async deleteData(id) {
        try {
            await axios.delete(`http://localhost:3000/users/${id}`);
            console.log(`Data with id ${id} has been deleted.`);
        } catch (error) {
            console.log(error);
        }
    }

    static async updateData(id, data) {
        try {
            await axios.put(`http://localhost:3000/users/${id}`, data);
            console.log(`Data with id ${id} has been updated.`);
        } catch (error) {
            console.log(error);
        }
    }

    static async getDataById(id) {
        try {
            const response = await axios.get(`http://localhost:3000/users/${id}`);
            return response.data;
        } catch (error) {
            console.log(error);
            throw error;
        }
    }

    static async getLastId() {
        try {
            const response = await axios.get('http://localhost:3000/products');
            return response.data[response.data.length - 1].id;
        } catch (error) {
            console.log(error);
            throw error;
        }
    }
}


// order

export class orderService {
    static async fetchData(url) {
        try {
            const response = await axios.get(url);
            return response.data;
        } catch (error) {
            console.log(error);
            throw error;
        }
    }

    static async addData(data) {
        try {
            await axios.post('http://localhost:3000/orders', data);
            console.log('Data has been added.');
        } catch (error) {
            console.log(error);
        }
    }
    
    static async deleteData(id) {
        try {
            await axios.delete(`http://localhost:3000/orders/${id}`);
            console.log(`Data with id ${id} has been deleted.`);
        } catch (error) {
            console.log(error);
        }
    }

    static async updateData(id, data) {
        try {
            await axios.put(`http://localhost:3000/orders/${id}`, data);
            console.log(`Data with id ${id} has been updated.`);
        } catch (error) {
            console.log(error);
        }
    }

    static async getDataById(id) {
        try {
            const response = await axios.get(`http://localhost:3000/orders/${id}`);
            return response.data;
        } catch (error) {
            console.log(error);
            throw error;
        }
    }

    static async getLastId() {
        try {
            const response = await axios.get('http://localhost:3000/orders');
            return response.data[response.data.length - 1].id;
        } catch (error) {
            console.log(error);
            throw error;
        }
    }
}
