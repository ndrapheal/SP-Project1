import { productService } from "../model/model.js";

// Function to show products
const showPro = () => {
  const rowDiv = document.querySelector("div.row");

  // Ensure the div is empty before appending new products
  rowDiv.innerHTML = "";

  // Fetch data and populate the products
  productService.fetchData("http://localhost:3000/products").then((data) => {
    data.forEach((item) => {
      rowDiv.innerHTML += `
        <div class="col-sm-6 col-md-4 col-lg-3">
          <div class="box">
            <a href="">
              <div class="img-box">
                <img src="images/${item.image}" alt="${item.name}">
              </div>
              <div class="detail-box">
                <h6>
                  ${item.name}
                </h6>
                <h6>
                  Price
                  <span>
                    $${item.price}
                  </span>
                </h6>
              </div>
              <div class="new">
                <span>
                  ${item.new ? 'New' : ''}
                </span>
              </div>
            </a>
          </div>
        </div>
      `;
    });
  });
};

// Call showPro function to display products initially



const addPro = () => {
  const name = document.getElementById("name").value;
  const fileInput = document.getElementById("image");
  const image = fileInput.files[0] ? fileInput.files[0].name : "No file chosen";
  const price = document.getElementById("price").value;
  const sale = document.getElementById("sale").value;
  const category = document.getElementById("category").value;
  const description = document.getElementById("discription").value;
  var hotdeal = document.getElementById("new").checked;
  productService.getLastId().then((id) => {
    const newPro = {
      id: (Number(id) + 1).toString(),
      name: name,
      image: image,
      category: category,
      price: price,
      sale: sale,
      new: hotdeal == true ? 1 : 0,
      star: 5,
      description: description,
    };
    productService.addData(newPro);
  });
  showPro();
  modal.style.display = "none";
};

showPro();

//// viết chức năng thêm sản phẩm
var modal = document.getElementById("myModal");

// chức năng đóng popup thêm sản phẩm
var btn = document.getElementById("openAddPage");
btn.onclick = () => (modal.style.display = "block");
var span = document.getElementsByClassName("close")[0];
span.onclick = function () {
  modal.style.display = "none";
};

// click út addPro để mở popup thêm sản phẩm
document.querySelector("#addPro").addEventListener("click", addPro);

// xoá sản phẩm
const deletePro = (id) => {
  productService.deleteData(id);
};

// viết chức năng xóa sản phẩm
document.querySelector("div").addEventListener("click", function (e) {
  if (e.target.classList.contains("deletePro")) {
    const id = e.target.dataset.id;
    console.log(id);
    //productService.deleteData(id);
    deletePro(id);
    showPro();
  }
});

// viết chức năng sửa sản phẩm
var editModal = document.getElementById("editModal");

document.querySelector("div").addEventListener("click", function (e) {
  if (e.target.classList.contains("openEditPage")) {
    const id = e.target.dataset.id;
    productService.getDataById(id).then((pro) => {
      editModal.style.display = "block";
      editModal.innerHTML = `
    <div class="modal-content">
                        <span class="close">&times;</span>
                        <label for="">Tên sản phẩm</label>
                        <br />
                        <input value="${pro.name}" type="text" id="editName" />
                        <br />
                        <label for="">Hình ảnh</label>
                        <br />
                        <img id="showImage"  src="../site/image/${pro.image}" width="120">
                        <br />
                        <input type="file" id="editImage" />
                        <input type="hidden" id="oldImage" value="${pro.image}" />
                        <br />
                        <label for="">Danh mục</label>
                        <br />
                        <section>
                          <select id="editCategory">
                            <option ${pro.category == "Tivi" ? "selected" : ""} value="Tivi">Tivi</option>
                            <option ${pro.category == "tủ lạnh" ? "selected" : ""} value="tủ lạnh">tủ lạnh</option>
                          </select>
                        </section>
                        <br />
                        <label for="">Giá</label>
                        <br />
                        <input value="${pro.price}" type="text" id="editPrice" />
                        <label for="">Giá khuyến mãi</label>
                        <br />
                        <input value="${pro.sale}" type="text" id="editSale" />
                        <label for="">HotDeal</label>
                        <br />
                        <input ${pro.hotdeal == 1 ? "checked" : ""} type="checkbox" id="editHotdeal" />
                        <br />
                        <label for="">Đánh giá</label>
                        <br />
                        <input value="${pro.star}" type="text" id="editStar" />
                        <label for="">Mô tả</label>
                        <br />
                        <input value="${pro.description}" type="text" id="editDescription" />
                        <br />
                        <button class="editPro" data-id="${id}">Sửa</button>
                      </div>
    `;
    });
  }
});

editModal.addEventListener("click", function (e) {
  if (e.target.classList.contains("editPro")) {
    const id = e.target.dataset.id;
    const name = document.getElementById("editName").value;

    const oldImage = document.getElementById("oldImage").value;
    const fileInput = document.getElementById("editImage");
    const image = fileInput.files[0] ? fileInput.files[0].name : oldImage;

    const price = document.getElementById("editPrice").value;
    const sale = document.getElementById("editSale").value;
    const category = document.getElementById("editCategory").value;
    const description = document.getElementById("editDescription").value;
    const star = document.getElementById("editStar").value;
    var editHotdealCheckbox = document.getElementById("editHotdeal");
    var editHotdeal = editHotdealCheckbox.checked;
    editHotdealCheckbox.addEventListener("change", function () {
      editHotdeal = this.checked ? 1 : 0;
    });
    console.log(
      id + name + image + price + sale + category + description + star
    );
    productService.updateData(id, {
      name: name,
      image: image,
      category: category,
      price: price,
      sale: sale,
      hotdeal: editHotdeal == true ? 1 : 0,
      star: star,
      description: description,
    });
    showPro();
    editModal.style.display = "none";
  }
});
